<?php

class Bmipasien_model extends CI_Model{

    public $id;
    public $tanggal;
    public $berat;
    public $tinggi;
    public $bmi;
    public $status_bmi;
    public $catatan;
    public $pasien_id;

}




?>