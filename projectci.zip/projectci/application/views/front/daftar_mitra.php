<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SILOKERNF</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/siloker.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
</head>
<body>
	<div class="container-fluid mb-2">
		<div class="py-5 my-2 col-md-offset-0 " style="background-image: url(image/img_bg_4.jpg);" data-stellar-background-ratio="1">
		<h3 class="text-center mt-4 mb-3 text-black"><b>Sistem Informasi Lowongan Kerja NF</b></h3>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-toggleable-sm navbar-light bg-light" style="background-color: rgb(240, 240, 240);">
						 
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="navbar-toggler-icon"></span>
						</button> <a class="navbar-brand" href="<?php echo base_url()?>index.php/welcome/index" style="color: rgb(49, 6, 241);"><b> SILOKERNF</b></a>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="navbar-nav me-auto mb-2 mb-lg-0">
								<li class="nav-item">
								  <a class="nav-link"aria-current="page" href="home.php"><i class="fas fa-home" aria-hidden="true"></i> Home</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/lowongan" >Lowongan Baru</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link " href="<?php echo base_url()?>index.php/welcome/loker">Isi Loker</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/mitra">Daftar Mitra</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/berita">Berita</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo base_url()?>index.php/welcome/about">About</a>
								  </li>
								
							</ul>
							<form class="form-inline ml-md-auto"><i class="fas fa-search" aria-hidden="true"></i>
								<input class="form-control mr-sm-2" type="search" placeholder="Search">
								<ul class="navbar-nav ml-md-auto">
									<li class="nav-item active">
										 <a class="nav-link" href="<?php base_url()?> index.php/login/login"><i class="far fa-user-circle"></i>Login <span class="sr-only">(current)</span></a>
									</li>
								</ul>
							</form>
								
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	<div class="row" style="margin-top: 50px; margin-bottom: 50px;">
		<div class="col-sm-12">
		  <div class="card shadow-sm" style="border-radius: 10px;">
			<div class="d-flex justify-content-end mt-2">
			  <ol class="breadcrumb" style="margin-right: 50px;">
				<li class="breadcrumb-item"><a href="index.html">Home</a></li>
				<li class="breadcrumb-item active" aria-current="page">Daftar Mitra</li>
			  </ol>
			</div>
			<div class="card-body" style="margin-left: 20px; margin-right: 20px; margin-bottom: 50px">
			  <a href="daftar_menjadi_mitra.html">Daftar Menjadi Mitra</a> <br><br>

			  <!-- isinya -->
			  <h3  style="text-align: center; color:rgb(10, 43, 190);"> Mitra Perusahaan Kami </h3> <br>
			  
  
			  <div >
				<h5 style="color:rgb(10, 43, 190);"> PT Jaya </h5> 
				<p>PT Jaya merupakan salah satu perusahaan yang bergerak di bidang Teknologi yang bertempat di Bandung, Jawa Barat. Perusahaan ini mulai berdiri pada tahun 1990  yang didirikan oleh beberapa tenaga profesional di bidangnya masing-masing. perusahaan ini memiliki banyak pengalaman diantaranya yaitu membangun Sistem Informasi dan Database, Aplikasi berbasis android/ios dan web dan masih banyak lagi </p>
  
			  </div> <br>
			 
			  <div>
				<h5 style="color:rgb(10, 43, 190);"> PT Fortuone </h5> 
				<p> PT Foryou merupakan perusahaan yang bergerak di bidang telekomunikasi. berdiri pada tahun 2004 yang bertempat di Makassar, Sulawesi Selatan. sudah banyak menara telekomunikasi yang tersebar di seluruh Indonesia menjadikan perusahaan ini terus berkembang dan maju.   </p>
			  </div> <br>
  
			  <div>
				<h5 style="color:rgb(10, 43, 190);"> PT Allbest </h5>
				<p> PT Allbest merupakan perusahaan Startup e-commerce. perusahaan ini berdiri pada tahun 1990 tepatnya di kota Jakarta. perusahaan ini merupakan salah satu e-commerce terbesar di Indonesia yang membuat perusahaan e-commerce ini semain maju.  </p> 
			  </div> 
			  <div>
				<h5 style= "color: rgb(10, 43, 190);"> PT Welnard </h5>
				<p> PT. Welnard merupakan salah satu startup yang berfokus untuk memajukan ekonomi tradisional. Perusahaan ini berdiri sejak tahun 2008 yang bergerak untuk membantu warung tradisional dengan menggunakan teknologi. Sampai saat ini sudah sekitar 2.500 kios yang tersebar menjadikan perusahaan ini berkembang dengan sangat baik.</p>
			  </div>
			</div>
		  </div>
		</div>
		
	</div>

	<footer class="bg-light" style="text-align: center; ">
		<div class="container p-2">
		  <p>Develop By Mahasiswa STT-NF @2021</p>
		</div>
	  </footer>
  

	  <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
	  <script src="js/scripts.js"></script>


  </body>
</html>	