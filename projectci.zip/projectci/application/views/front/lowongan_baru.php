<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SILOKERNF</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/siloker.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
	
</head>
<body>
	<div class="container-fluid mb-2">
		<div class="py-5 my-2 col-md-offset-0 " style="background-image: url(<?php echo base_url()?>/image/img_bg_4.jpg)"  data-stellar-background-ratio="1">
		<h3 class="text-center mt-4 mb-3 text-black"><b>Sistem Informasi Lowongan Kerja NF</b></h3>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-toggleable-sm navbar-light bg-light" style="background-color: rgb(240, 240, 240);">
						 
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="navbar-toggler-icon"></span>
						</button> <a class="navbar-brand" href="<?php echo base_url()?>index.php/welcome/home" style="color: rgb(49, 6, 241);"><b> SILOKERNF</b></a>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="navbar-nav me-auto mb-2 mb-lg-0">
								<li class="nav-item">
								  <a class="nav-link"aria-current="page" href="home.php"><i class="fas fa-home" aria-hidden="true"></i> Home</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/lowongan" >Lowongan Baru</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link " href="<?php echo base_url()?>index.php/welcome/loker">Isi Loker</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/mitra">Daftar Mitra</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/berita">Berita</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo base_url()?>index.php/welcome/about">About</a>
								  </li>
								
							</ul>
							<form class="form-inline ml-md-auto"><i class="fas fa-search" aria-hidden="true"></i>
								<input class="form-control mr-sm-2" type="search" placeholder="Search">
								<ul class="navbar-nav ml-md-auto">
									<li class="nav-item active">
										 <a class="nav-link" href="<?php base_url()?> index.php/login/login"><i class="far fa-user-circle"></i>Login <span class="sr-only">(current)</span></a>
									</li>
								</ul>
							</form>
								
							</ul>
						</div>
					</nav>
				</div>
			</div>
		</div>
	<div class="row" style="margin-top: 50px; margin-bottom: 50px;">
		<div class="col-sm-8">
		  <div class="card shadow-sm" style="border-radius: 10px;">
			<div class="d-flex justify-content-end mt-2">
			  <ol class="breadcrumb" style="margin-right: 50px;">
				<li class="breadcrumb-item"><a href="index.html">Home</a></li>
				<li class="breadcrumb-item active" aria-current="page">Lowongan Kerja Baru</li>
			  </ol>
			</div>
			<div class="card-body" style="margin-left: 50px;">
				<h3>Lowongan PT JAYA</h3>
				<p>dibutuhkan professional IT Database</p>
				<p>Kualifikasi</p>
				<ul>
				  <li>Sertifikat Professional, D3 (Diploma), D4 (Diploma), Sarjana (S1)</li>
				  <li>Spesialisasi Pekerjaan : Komputer/Teknologi Informasi, IT-Admin Jaringan/Sistem/Database</li>
				  <li>Menguasai konsep dari relational database atau No SQL Database serta design dan arsitektur database</li>
				</ul>
				<p>4 januari 2021, <a href="detail.html">Lihat Detail</a></p>
				<hr />
				<h3>Lowongan PT Allbest</h3>
				<p>Dibutuhkan contumer service E-commerce </p>
				<p>Kualifikasi</p>
				<ul>
				  <li>Diutamakan wanita</li>
				  <li>Memiliki pengalaman min. 2 tahun</li>
				  <li>Familiar dengan sistem e-commerce</li>
				</ul>
				<p>29 Desember 2020, <a href="detail2.html">Lihat Detail</a></p>
			</div>
		  </div>
		</div>
		<div class="col-sm-4 mt-2">
		  <ul class="list-group">
			<li class="list-group-item active" aria-current="true">Kategori Lowongan Kerja</li>
			<li class="list-group-item"> 
				<a href="lowongan_kategori_1.html">Kategori 1</a>
			</li>
			<li class="list-group-item"> 
				<a href="lowongan_kategori_2.html">Kategori 2</a>
			</li>
			<li class="list-group-item"> 
				<a href="lowongan_kategori_3.html">Kategori 3</a>
			</li>
			<li class="list-group-item"> 
				<a href="lowongan_kategori_4.html">Kategori 4</a>
			</li>
  
		  </ul>
		</div>
	  </div>

	  <footer class="bg-light" style="text-align: center; ">
		<div class="container p-2">
		  <p>Develop By Mahasiswa STT-NF @2021</p>
		</div>
	  </footer>

	  <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
	  <script src="js/scripts.js"></script>

  </body>
</html>	

	