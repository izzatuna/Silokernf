<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SILOKERNF</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/siloker.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
</head>
<body>
	<div class="container-fluid mb-2">
		<div class="py-5 my-2 col-md-offset-0 " style="background-image: url(image/img_bg_4.jpg);" data-stellar-background-ratio="1">
		<h3 class="text-center mt-4 mb-3 text-black"><b>Sistem Informasi Lowongan Kerja NF</b></h3>
		</div>
	</div>
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-toggleable-sm navbar-light bg-light" style="background-color: rgb(240, 240, 240);">
				 
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="navbar-toggler-icon"></span>
						</button> <a class="navbar-brand" href="<?php echo base_url()?>index.php/welcome/index" style="color: rgb(49, 6, 241);"><b> SILOKERNF</b></a>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="navbar-nav me-auto mb-2 mb-lg-0">
								<li class="nav-item">
								  <a class="nav-link"aria-current="page" href="home.php"><i class="fas fa-home" aria-hidden="true"></i> Home</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/lowongan" >Lowongan Baru</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link " href="<?php echo base_url()?>index.php/welcome/loker">Isi Loker</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/mitra">Daftar Mitra</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="<?php echo base_url()?>index.php/welcome/berita">Berita</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo base_url()?>index.php/welcome/about">About</a>
								  </li>
								
							</ul>
							<form class="form-inline ml-md-auto"><i class="fas fa-search" aria-hidden="true"></i>
								<input class="form-control mr-sm-2" type="search" placeholder="Search">
								<ul class="navbar-nav ml-md-auto">
									<li class="nav-item active">
										 <a class="nav-link" href="<?php base_url()?> index.php/login/login"><i class="far fa-user-circle"></i>Login <span class="sr-only">(current)</span></a>
									</li>
								</ul>
							</form>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	</div>
	<!--isi about-->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="row mt-5">
					<div class="col-md-6 team">
					<img src="image/alip.jpg" alt="alip">
				</br>
					<h6 style="text-align: center;">ALIPIA SALSABILLAH </br>  0110120194 </h6>
					</div>

					<div class="col-md-6 team">
					<img src="image/dita.jpg" alt="dita">
				</br>
					<h6 style="text-align: center;">DITA SYAHIDA PUTRI </br> 0110120183 </h6>
					</div>
		
					<div class="col-md-6 team">
					<img src="image/hani.jpg" alt="hani">
				</br>
					<h6 style="text-align: center;">IZZATUNA HANIFA </br> 0110120094 </h6>
					</div>

					<div class="col-md-6 team">
					<img src="image/lutfi.jpg" alt="lutfi">
				</br>
					<h6 style="text-align: center;">LUTFI ZAIN </br> 0110120169 </h6>
					</div>
				</div>
			</div>
		</div>
	</div>
</br>

	<footer class="bg-light" style="text-align: center; ">
		<div class="container p-2">
		  <p>Develop By Mahasiswa STT-NF @2021</p>
		</div>
	  </footer>

	  <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
	  <script src="js/scripts.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
      </script>

</body>