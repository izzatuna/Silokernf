<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>SILOKERNF</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/siloker.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
</head>
<body>
	<div class="container-fluid mb-2">
		<div class="py-5 my-2 col-md-offset-0 " style="background-image: url(image/img_bg_4.jpg);" data-stellar-background-ratio="1">
		<h3 class="text-center mt-4 mb-3 text-black"><b>Sistem Informasi Lowongan Kerja NF</b></h3>
		</div>
	</div>
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<nav class="navbar navbar-toggleable-sm navbar-light bg-light" style="background-color: rgb(240, 240, 240);">
				 
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="navbar-toggler-icon"></span>
				</button> <a class="navbar-brand" href="index.html" style="color: rgb(49, 6, 241);"><b> SILOKERNF</b></a>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
						  <a class="nav-link"aria-current="page" href="index.php"><i class="fas fa-home" aria-hidden="true"></i> Home</a>
						</li>
						<li class="nav-item">
						  <a class="nav-link" href="lowongan.php">Lowongan Baru</a>
						</li>
						<li class="nav-item">
						  <a class="nav-link" href="isiloker.php">Isi Loker</a>
						</li>
						<li class="nav-item">
						  <a class="nav-link" href="daftarmitra.php">Daftar Mitra</a>
						</li>
						<li class="nav-item">
						  <a class="nav-link" href="berita.php">Berita</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="about.php">About</a>
						  </li>
						
					</ul>
					<form class="form-inline ml-md-auto"><i class="fas fa-search" aria-hidden="true"></i>
						<input class="form-control mr-sm-2" type="search" placeholder="Search">
						<ul class="navbar-nav ml-md-auto">
							<li class="nav-item active">
								 <a class="nav-link" href="<?php base_url()?> index.php/login/login"><i class="far fa-user-circle"></i>Login <span class="sr-only">(current)</span></a>
							</li>
						</ul>
					</form>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	</div>

    <div class="row" style="margin-top: 50px; margin-bottom: 50px;">
        <div class="col-sm-12">
          <div class="card shadow-sm" style="border-radius: 10px;">
            <div class="d-flex justify-content-end mt-2">
              <ol class="breadcrumb" style="margin-right: 50px;">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item"><a href="daftar_menjadi_mitra.html">Daftar Mitra</a></li>
                <li class="breadcrumb-item active" aria-current="page">Form Menjadi Mitra</li>
              </ol>
            </div> <br>
            
            <div class="card-body" style="margin-left: 20px; margin-right: 10px;">
              <h3 class="card-title" style="color:rgb(10, 43, 190);">Form Menjadi Mitra </h3> <br>

              <!-- isinya-->
              <form>
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Nama Perusahaan/Organisasi</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" id="inputPassword" placeholder="Company/Organization">
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Bidang Usaha</label>
                  <div class="col-sm-8">
                    <select class="form-control" id="exampleFormControlSelect1">
                      <option>Perbankan</option>
                      <option>Desain Grafis</option>
                      <option>Startup</option>
                      <option>Web Design</option>
                      <option>Cloud Service</option>
                    </select>
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Alamat Kantor</label>
                  <div class="col-sm-8">
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Kontak Person</label>
                  <div class="col-sm-8">
                    <input type="number" class="form-control" id="inputPassword" placeholder="Contact">
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">No HP/Telpon </label>
                  <div class="col-sm-8">
                    <input type="number" class="form-control" id="inputPassword">
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Email</label>
                  <div class="col-sm-8">
                    <input type="email" class="form-control" id="inputPassword" placeholder="Email">
                  </div>
                </div>
  
                <div class="form-group row mb-2">
                  <label for="inputPassword" class="col-sm-4 col-form-label">Alamat Web</label>
                  <div class="col-sm-8">
                    <input type="url" class="form-control" id="inputPassword">
                  </div>
                </div> <br><br>

                <div class="form-group row mb-2">
                  <div class="col-sm-1" style="margin-right:50px;">
                    <button herf="" class="btn btn-success " type="submit">Submit</button>
                  </div>
                  <div class="col-sm-1" style="margin-right:50px;" >
                    <button class="btn btn-danger " type="submit">Cancel</button>
                  </div>
                </div>
  
              </form>
  
            </div>
          </div>
        </div>
        
      </div>
    </div>

    <footer class="bg-light" style="text-align: center; ">
      <div class="container p-2">
        <p>Develop By Mahasiswa STT-NF @2021</p>
      </div>
    </footer>



    <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    
  </body>  
</html>
   
	